import dotenv from 'dotenv';
import Razorpay from 'razorpay';
dotenv.config();

import Tiket from '../models/tiketsmodal.js';

import Booktiket from '../models/booktiketmodal.js';

export const getallTikets = async (req, res) => {
    try {

        const tikets = await Tiket.find();

        if(!tikets){
            return res.status(404).json({ message: 'No tikets found' });
        }

        res.status(200).json(tikets);
        
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}

const instance = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,       
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

export const BookTicket = async (req, res) => {
    try {

        const {TicketName , TicketId , Name  , Phone , TicketQuantity , TotalPrice , TiketPrice} = req.body

        if(!TicketName || !TicketId || !Name || !Phone || !TicketQuantity || !TotalPrice || !TiketPrice){
            return res.status(400).json({ message: 'Please fill all fields' });
        }

        const ticket = await Tiket.findById(TicketId);

        if(!ticket){
            return res.status(404).json({ message: 'Ticket not found' });
        }

        if(!TotalPrice === (TicketQuantity * TiketPrice)){
            res.status(400).json({ message: 'Total Price is not equal to Ticket Quantity * Tiket Price' });
        }


        const newBook = new Booktiket({
            TicketName,
            TicketId,
            Name,
            Phone,
            TicketQuantity,
            TotalPrice,
            TiketPrice,
        });


        const option = {
            amount: TotalPrice * 100,
            currency: "INR",
            receipt: new Date().toISOString()
        }

        const order = await instance.orders.create(option)

        // await newBook.save();

        res.status(201).json("Ticket Book Sucssesfully" , order);
        
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: error.message });
    }
}


// export const createorder = async (req, res) => {
//     try {

//         const {TicketId , TicketName , TicketQuantity , TotalPrice , TiketPrice} = req.body;

//         if(!TicketId || !TicketName || !TicketQuantity || !TotalPrice){
//             return res.status(400).json({ message: 'Please fill all fields' });
//         }

//         if(!TotalPrice === (TicketQuantity * TiketPrice)){
//             res.status(400).json({ message: 'Total Price is not equal to Ticket Quantity * Tiket Price' });
//         }

//         const option = {
//             amount : TotalPrice * 100,
//             currency : "INR",
//             TicketName : TicketName,
//             TicketQuantity : TicketQuantity,
//         }
        
//     } catch (error) {
//         res.status(500).json({ message: error.message });
//     }
// }